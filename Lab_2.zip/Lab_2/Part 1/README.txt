Commands to run Dockerfile:
sudo su
docker build -t lab2 .
docker run lab2
# or docker run -it lab2 /bin/bash
